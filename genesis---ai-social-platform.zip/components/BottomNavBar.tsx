// FIX: Replaced placeholder content with full component implementation.
import React from 'react';
import { Icon } from './Icon';
import type { View } from '../App';

interface BottomNavBarProps {
  activeView: View;
  onNavigate: (view: View) => void;
  onAddClick: () => void;
}

const NavItem: React.FC<{
  iconName: string;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ iconName, label, isActive, onClick }) => {
  const activeClass = isActive ? 'text-purple-400' : 'text-slate-400';
  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 transition-colors hover:text-white ${activeClass}`}>
      <Icon name={iconName} />
      <span className="text-xs">{label}</span>
    </button>
  );
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeView, onNavigate, onAddClick }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/80 backdrop-blur-lg border-t border-slate-700/50 z-20">
      <div className="container mx-auto px-4 h-16 flex justify-around items-center">
        <NavItem iconName="home" label="Feed" isActive={activeView === 'feed'} onClick={() => onNavigate('feed')} />
        <NavItem iconName="explore" label="Explore" isActive={activeView === 'explore'} onClick={() => onNavigate('explore')} />
        <button onClick={onAddClick} className="w-12 h-12 bg-gradient-to-tr from-purple-600 to-cyan-500 rounded-full flex items-center justify-center text-white shadow-lg transform -translate-y-4 hover:scale-110 transition-transform">
          <Icon name="add" className="w-8 h-8"/>
        </button>
        <NavItem iconName="messages" label="Messages" isActive={activeView === 'messages'} onClick={() => onNavigate('messages')} />
        <NavItem iconName="profile" label="Profile" isActive={activeView === 'profile'} onClick={() => onNavigate('profile')} />
      </div>
    </nav>
  );
};
