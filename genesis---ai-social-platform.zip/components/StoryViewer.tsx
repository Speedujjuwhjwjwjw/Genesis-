import React, { useEffect, useState } from 'react';
import type { Story } from '../types';

interface StoryViewerProps {
  story: Story;
  onClose: () => void;
}

export const StoryViewer: React.FC<StoryViewerProps> = ({ story, onClose }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(onClose, story.duration);
    
    const interval = setInterval(() => {
      setProgress(p => p + 100 / (story.duration / 50));
    }, 50);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [story, onClose]);

  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center animate-fade-in" onClick={onClose}>
      <div className="relative w-full max-w-lg h-full max-h-[90vh] rounded-lg overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="absolute top-2 left-2 right-2 h-1 bg-slate-500/50 rounded-full overflow-hidden">
            <div className="h-full bg-white rounded-full" style={{ width: `${progress}%`, transition: 'width 50ms linear' }}></div>
        </div>
        
        <img src={story.imageUrl} alt="Story" className="w-full h-full object-cover" />

        <div className="absolute top-6 left-4 flex items-center gap-3">
            <img src={story.author.avatarUrl} alt={story.author.name} className="w-10 h-10 rounded-full border-2 border-white" />
            <p className="text-white font-bold text-sm shadow-lg">{story.author.name}</p>
        </div>

        {story.text && (
            <div className="absolute bottom-10 left-0 right-0 p-4 flex justify-center">
                <p className="text-white text-2xl font-bold text-center bg-black/50 px-4 py-2 rounded-lg shadow-2xl">
                    {story.text}
                </p>
            </div>
        )}
        
        <button onClick={onClose} className="absolute top-2 right-2 text-white/80 hover:text-white transition-colors p-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
    </div>
  );
};