
import React from 'react';

export const LoadingCard: React.FC = () => {
  return (
    <div className="bg-slate-800 rounded-2xl shadow-lg overflow-hidden border border-slate-700">
      <div className="p-4 flex items-center space-x-3 animate-pulse">
        <div className="h-10 w-10 rounded-full bg-slate-700"></div>
        <div>
          <div className="h-4 w-24 bg-slate-700 rounded"></div>
          <div className="h-3 w-16 bg-slate-700 rounded mt-2"></div>
        </div>
      </div>

      <div className="px-4 pb-4 animate-pulse space-y-2">
        <div className="h-4 bg-slate-700 rounded w-full"></div>
        <div className="h-4 bg-slate-700 rounded w-5/6"></div>
        <div className="h-4 bg-slate-700 rounded w-3/4"></div>
      </div>
      
      <div className="w-full h-80 bg-slate-700 animate-pulse"></div>
      
       <div className="p-4 flex justify-around items-center border-t border-slate-700 animate-pulse">
         <div className="h-6 w-20 bg-slate-700 rounded"></div>
         <div className="h-6 w-20 bg-slate-700 rounded"></div>
         <div className="h-6 w-20 bg-slate-700 rounded"></div>
       </div>
    </div>
  );
};
