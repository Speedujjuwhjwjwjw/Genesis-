import React from 'react';

interface ApiKeySelectorProps {
  onSelectKey: () => void;
}

export const ApiKeySelector: React.FC<ApiKeySelectorProps> = ({ onSelectKey }) => {
  return (
    <div className="text-center animate-fade-in">
      <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
        Video Generation Requires Your API Key
      </h2>
      <p className="mt-4 text-slate-400">
        To generate videos with Veo, you need to select a Google AI Studio API key from a project with billing enabled.
      </p>
      <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline mt-2 inline-block">
        Learn more about billing
      </a>
      <button
        onClick={onSelectKey}
        className="mt-6 w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105"
      >
        Select API Key
      </button>
    </div>
  );
};
