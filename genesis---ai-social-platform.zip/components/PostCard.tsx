// FIX: Replaced placeholder content with full component implementation.
import React from 'react';
import type { Post } from '../types';
import { Icon } from './Icon';

interface PostCardProps {
  post: Post;
}

export const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const formatStat = (num: number) => {
    if (num > 1000) {
      return `${(num/1000).toFixed(1)}k`;
    }
    return num;
  }
  
  return (
    <div className="bg-slate-800 rounded-2xl shadow-lg overflow-hidden border border-slate-700/50">
        <div className="p-4 flex items-center space-x-3">
            <img className="h-10 w-10 rounded-full" src={post.author.avatarUrl} alt={post.author.name} />
            <div>
                <p className="text-sm font-semibold text-slate-200">{post.author.name}</p>
                <p className="text-xs text-slate-400">{new Date(post.timestamp).toLocaleDateString()}</p>
            </div>
        </div>
        <div className="px-4 pb-4">
            <p className="text-slate-300">{post.text}</p>
        </div>
        <img src={post.imageUrl} alt="Post content" className="w-full h-auto object-cover bg-slate-700" style={{aspectRatio: '1/1'}} />
       
       <div className="p-4 flex justify-around items-center border-t border-slate-700/50 text-slate-400">
         <button className="flex items-center gap-2 hover:text-red-500 transition-colors">
            <Icon name="like" className="w-6 h-6"/>
            <span className="text-sm font-semibold">{formatStat(post.stats.likes)}</span>
         </button>
         <button className="flex items-center gap-2 hover:text-cyan-400 transition-colors">
            <Icon name="comment" className="w-6 h-6"/>
            <span className="text-sm font-semibold">{formatStat(post.stats.comments)}</span>
         </button>
         <button className="flex items-center gap-2 hover:text-green-400 transition-colors">
            <Icon name="share" className="w-6 h-6"/>
            <span className="text-sm font-semibold">{formatStat(post.stats.shares)}</span>
         </button>
       </div>
    </div>
  );
};
