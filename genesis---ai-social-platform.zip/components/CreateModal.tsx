import React, { useState } from 'react';
import { CreatePostForm } from './CreatePostForm';
import { StoryGeneratorForm } from './StoryGeneratorForm';
import { VideoGeneratorForm } from './VideoGeneratorForm';

type CreateMode = 'Post' | 'Story' | 'Journey';

interface CreateModalProps {
  onClose: () => void;
  onGeneratePost: (topic: string) => void; // Kept for potential future use
  onGenerateStory: (topic: string) => void;
  onGenerateVideo: (prompt: string, image?: { data: string; mimeType: string }) => void;
  onCreatePost: (caption: string, file: File) => void;
}

const TabButton: React.FC<{ label: string; isActive: boolean; onClick: () => void; }> = ({ label, isActive, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm font-bold rounded-full transition-colors ${
        isActive
          ? 'bg-purple-600 text-white'
          : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
      }`}
    >
      {label}
    </button>
  );
};


export const CreateModal: React.FC<CreateModalProps> = ({ onClose, onGenerateStory, onGenerateVideo, onCreatePost }) => {
  const [mode, setMode] = useState<CreateMode>('Post');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerateStory = async (topic: string) => {
      setIsLoading(true);
      await onGenerateStory(topic);
      setIsLoading(false);
  }

  const handleGenerateVideo = async (prompt: string, image?: { data: string; mimeType: string }) => {
      // The loading state for video is handled in the main App component
      // because it's a long, multi-stage process.
      onGenerateVideo(prompt, image);
  }

  return (
    <div className="fixed inset-0 bg-black/80 z-40 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl w-full max-w-md shadow-2xl border border-slate-700" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-slate-700 flex justify-between items-center">
          <h2 className="text-lg font-bold text-white">Create</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>
        
        <div className="p-4">
          <div className="flex justify-center items-center gap-2 mb-4">
            <TabButton label="Post" isActive={mode === 'Post'} onClick={() => setMode('Post')} />
            <TabButton label="Story" isActive={mode === 'Story'} onClick={() => setMode('Story')} />
            <TabButton label="Journey" isActive={mode === 'Journey'} onClick={() => setMode('Journey')} />
          </div>

          {mode === 'Post' && <CreatePostForm onCreatePost={onCreatePost} onClose={onClose}/>}
          {mode === 'Story' && <StoryGeneratorForm onGenerate={handleGenerateStory} isLoading={isLoading} />}
          {mode === 'Journey' && <VideoGeneratorForm onGenerate={handleGenerateVideo} isLoading={isLoading} />}
        </div>
      </div>
    </div>
  );
};
