import React from 'react';
import type { Story } from '../types';
import { Icon } from './Icon';

interface StoriesBarProps {
  stories: Story[];
  onStoryClick: (story: Story) => void;
  onAddStoryClick: () => void;
}

const StoryPreview: React.FC<{ story: Story, onClick: () => void }> = ({ story, onClick }) => (
    <div className="flex-shrink-0 flex flex-col items-center gap-2 cursor-pointer group" onClick={onClick}>
        <div className="relative w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500">
            <div className="bg-slate-900 p-1 rounded-full w-full h-full">
                <img src={story.author.avatarUrl} alt={story.author.name} className="rounded-full w-full h-full object-cover" />
            </div>
        </div>
        <p className="text-xs text-slate-300 truncate w-16 text-center">{story.author.name}</p>
    </div>
);

const AddStoryButton: React.FC<{ onClick: () => void }> = ({ onClick }) => (
     <div className="flex-shrink-0 flex flex-col items-center gap-2 cursor-pointer group" onClick={onClick}>
        <div className="relative w-16 h-16 rounded-full p-[2px] bg-slate-700">
            <div className="bg-slate-800 p-1 rounded-full w-full h-full flex items-center justify-center">
                <Icon name="add" className="text-slate-400 w-8 h-8"/>
            </div>
        </div>
        <p className="text-xs text-slate-400 truncate w-16 text-center">Your Story</p>
    </div>
)

export const StoriesBar: React.FC<StoriesBarProps> = ({ stories, onStoryClick, onAddStoryClick }) => {
  return (
    <div className="py-4 border-b border-slate-700/50">
      <div className="flex items-center gap-4 overflow-x-auto pb-2 -mb-2 px-4 sm:px-0">
        <AddStoryButton onClick={onAddStoryClick} />
        {stories.map(story => (
          <StoryPreview key={story.id} story={story} onClick={() => onStoryClick(story)} />
        ))}
      </div>
    </div>
  );
};