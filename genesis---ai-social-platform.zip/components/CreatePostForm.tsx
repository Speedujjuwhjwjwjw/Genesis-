import React, { useState, useRef } from 'react';
import { generateCaptionAndHashtags } from '../services/geminiService'; // Assuming this function exists now

interface CreatePostFormProps {
    onCreatePost: (caption: string, file: File) => void;
    onClose: () => void;
}

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};


export const CreatePostForm: React.FC<CreatePostFormProps> = ({ onCreatePost, onClose }) => {
    const [file, setFile] = useState<File | null>(null);
    const [preview, setPreview] = useState<string | null>(null);
    const [caption, setCaption] = useState('');
    const [isSuggesting, setIsSuggesting] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            setFile(selectedFile);
            setPreview(URL.createObjectURL(selectedFile));
        }
    };

    const handleSuggestCaption = async () => {
        if (!file || !file.type.startsWith('image/')) {
            alert("Please select an image to suggest a caption.");
            return;
        }
        setIsSuggesting(true);
        try {
            const imagePart = await fileToGenerativePart(file);
            const suggestedCaption = await generateCaptionAndHashtags(imagePart);
            setCaption(suggestedCaption);
        } catch (error) {
            console.error("Failed to suggest caption:", error);
            alert("Could not suggest a caption. Please try again.");
        } finally {
            setIsSuggesting(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!file || !caption.trim()) {
            alert("Please select a file and write a caption.");
            return;
        }
        setIsUploading(true);
        await onCreatePost(caption, file);
        setIsUploading(false);
        onClose(); // Close modal on successful post
    };

    return (
        <form onSubmit={handleSubmit} className="mt-2 flex flex-col gap-4">
            {!preview ? (
                 <div className="w-full">
                    <label htmlFor="file-upload" className="flex flex-col items-center justify-center w-full h-48 border-2 border-slate-700 border-dashed rounded-lg cursor-pointer bg-slate-900/50 hover:bg-slate-800/60 transition-colors">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                            <svg className="w-8 h-8 mb-4 text-slate-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16"><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"/></svg>
                            <p className="mb-2 text-sm text-slate-500"><span className="font-semibold">Click to upload Photo or Video</span></p>
                        </div>
                        <input id="file-upload" ref={fileInputRef} type="file" className="hidden" onChange={handleFileChange} accept="image/*,video/*" />
                    </label>
                </div> 
            ) : (
                <div className="w-full aspect-square rounded-lg overflow-hidden bg-black flex items-center justify-center">
                    {file?.type.startsWith('image/') ? (
                        <img src={preview} alt="Preview" className="max-h-full max-w-full object-contain" />
                    ) : (
                        <video src={preview} controls className="max-h-full max-w-full" />
                    )}
                </div>
            )}
            
            {file && file.type.startsWith('image/') && (
                <button
                    type="button"
                    onClick={handleSuggestCaption}
                    disabled={isSuggesting}
                    className="w-full flex items-center justify-center text-sm bg-slate-700 hover:bg-slate-600 text-purple-300 font-bold py-2 px-4 rounded-lg transition-colors disabled:opacity-50"
                >
                    {isSuggesting ? 'Thinking...' : 'Suggest Caption ✨'}
                </button>
            )}

            <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Write a caption..."
                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 placeholder-slate-500 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200 resize-none"
                rows={3}
            />

            <button
                type="submit"
                disabled={!file || !caption.trim() || isUploading}
                className="w-full flex items-center justify-center bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {isUploading ? 'Sharing...' : 'Share Post'}
            </button>
        </form>
    );
};
