import React from 'react';
import type { VideoData } from '../types';
import { Icon } from './Icon';

interface VideoCardProps {
  video: VideoData;
}

export const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  const formatStat = (num: number) => {
    if (num > 1000) {
      return `${(num/1000).toFixed(1)}k`;
    }
    return num;
  };
  
  const renderVideoPlayer = () => {
    if (video.bunnyVideoId) {
        // Bunny.net integration using iframe for best compatibility
        return (
             <iframe
                src={`https://iframe.mediadelivery.net/embed/146516/${video.bunnyVideoId}?autoplay=false&loop=false&muted=false&preload=true`}
                loading="lazy"
                className="w-full h-full"
                style={{ position: 'absolute', top: 0, left: 0, border: 'none' }}
                allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;"
                allowFullScreen={true}
              ></iframe>
        );
    }
    
    if (video.videoUrl) {
      // AI Generated video (data URL)
      return (
         <video
            src={video.videoUrl}
            controls
            playsInline
            className="w-full h-full object-cover"
         />
      );
    }
    
    return <div className="bg-black text-white flex items-center justify-center">Video not available</div>;
  };

  return (
    <div className="bg-slate-800 rounded-2xl shadow-lg overflow-hidden border border-slate-700/50">
      <div className="p-4 flex items-center space-x-3">
        <img className="h-10 w-10 rounded-full" src={video.author.avatarUrl} alt={video.author.name} />
        <div>
          <p className="text-sm font-semibold text-slate-200">{video.author.name}</p>
          <p className="text-xs text-slate-400">{new Date(video.timestamp).toLocaleDateString()}</p>
        </div>
      </div>
      <div className="px-4 pb-4">
        <p className="text-slate-300">{video.text}</p>
      </div>
      
      <div className="w-full bg-black" style={{position: 'relative', paddingTop: '177.77%' /* 9:16 Aspect Ratio */ }}>
         {renderVideoPlayer()}
      </div>
       
       <div className="p-4 flex justify-around items-center border-t border-slate-700/50 text-slate-400">
         <button className="flex items-center gap-2 hover:text-red-500 transition-colors">
            <Icon name="like" className="w-6 h-6"/>
            <span className="text-sm font-semibold">{formatStat(video.stats.likes)}</span>
         </button>
         <button className="flex items-center gap-2 hover:text-cyan-400 transition-colors">
            <Icon name="comment" className="w-6 h-6"/>
            <span className="text-sm font-semibold">{formatStat(video.stats.comments)}</span>
         </button>
         <button className="flex items-center gap-2 hover:text-green-400 transition-colors">
            <Icon name="share" className="w-6 h-6"/>
            <span className="text-sm font-semibold">{formatStat(video.stats.shares)}</span>
         </button>
       </div>
    </div>
  );
};
