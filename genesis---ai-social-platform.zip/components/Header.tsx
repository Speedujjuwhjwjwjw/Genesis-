// FIX: Replaced placeholder content with full component implementation.
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 bg-slate-900/80 backdrop-blur-lg z-10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4 border-b border-slate-700/50">
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
            GenZ
          </h1>
          {/* Could add action icons here later if needed */}
        </div>
      </div>
    </header>
  );
};
