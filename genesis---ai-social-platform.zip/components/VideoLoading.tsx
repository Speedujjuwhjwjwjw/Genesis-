import React from 'react';

interface VideoLoadingProps {
    message: string;
}

export const VideoLoading: React.FC<VideoLoadingProps> = ({ message }) => {
    return (
        <div className="mt-8 text-center p-6 bg-slate-800 rounded-2xl border border-slate-700 animate-fade-in">
             <svg className="animate-spin mx-auto h-8 w-8 text-purple-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
             <p className="mt-4 text-slate-300 font-medium transition-all duration-500">{message}</p>
             <p className="mt-1 text-xs text-slate-500">Video generation can take a few minutes. Please keep this tab open.</p>
        </div>
    );
};
