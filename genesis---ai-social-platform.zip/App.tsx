import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNavBar } from './components/BottomNavBar';
import { FeedView } from './views/FeedView';
import { ExploreView } from './views/ExploreView';
import { ProfileView } from './views/ProfileView';
import { MessagesView } from './views/MessagesView';
import { ConversationView } from './views/ConversationView';
import { CreateModal } from './components/CreateModal';
import { StoryViewer } from './components/StoryViewer';
import { ApiKeySelector } from './components/ApiKeySelector';
import { VideoLoading } from './components/VideoLoading';

import { generatePost, generateStory, generateVideo } from './services/geminiService';
import { uploadVideo as uploadVideoToBunny } from './services/bunnyService';

import type { FeedItem, Story, Conversation, AIPersona, Author, Post, VideoData } from './types';
import { INITIAL_CONVERSATIONS } from './util/data';

// --- MOCK DATA ---
const USER_PROFILE: Author = {
    id: 'user-001',
    name: 'You',
    avatarUrl: '/avatars/user.png',
    isUser: true,
};

const MOCK_STORIES: Story[] = [
    { id: 'story-1', author: { id: 'chef-julia', name: 'Chef Julia', avatarUrl: '/avatars/julia.png' }, imageUrl: '/stories/story1.jpg', text: "Bon Appétit!", duration: 5000 },
    { id: 'story-2', author: { id: 'cosmic-carl', name: 'Cosmic Carl', avatarUrl: '/avatars/carl.png' }, imageUrl: '/stories/story2.jpg', text: "Stargazing", duration: 5000 },
];
// --- END MOCK DATA ---


export type View = 'feed' | 'explore' | 'messages' | 'profile';

const App: React.FC = () => {
    const [view, setView] = useState<View>('feed');
    const [feedItems, setFeedItems] = useState<FeedItem[]>([]);
    const [stories, setStories] = useState<Story[]>(MOCK_STORIES);
    const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);
    
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [isCreateModalOpen, setCreateModalOpen] = useState<boolean>(false);
    const [currentStory, setCurrentStory] = useState<Story | null>(null);

    // --- CHAT STATE ---
    const [isConversationView, setConversationView] = useState<boolean>(false);
    const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);

    // --- VIDEO GENERATION STATE ---
    const [hasApiKey, setHasApiKey] = useState<boolean | null>(null);
    const [isVideoLoading, setIsVideoLoading] = useState<boolean>(false);
    const [videoLoadingMessage, setVideoLoadingMessage] = useState<string>('');
    const [generatedVideo, setGeneratedVideo] = useState<VideoData | null>(null);
    

    useEffect(() => {
        // Generate an initial post for the feed on first load
        const fetchInitialPost = async () => {
            setIsLoading(true);
            try {
                const initialPost = await generatePost("a stunning photograph of a futuristic city");
                setFeedItems([initialPost]);
            } catch (error) {
                console.error("Failed to generate initial post:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchInitialPost();
    }, []);

    const handleNavigate = (newView: View) => {
        if (newView === 'messages') {
            setView('messages');
        } else {
            setConversationView(false); // Exit conversation view when navigating elsewhere
            setView(newView);
        }
    };
    
    const handleConversationSelect = (persona: AIPersona) => {
        const conversation = conversations.find(c => c.persona.id === persona.id);
        if (conversation) {
            setCurrentConversation(conversation);
            setConversationView(true);
        }
    };

    const handleUpdateConversation = (updatedConversation: Conversation) => {
        setConversations(prev =>
            prev.map(c => c.persona.id === updatedConversation.persona.id ? updatedConversation : c)
        );
        setCurrentConversation(updatedConversation);
    };

    // --- CONTENT CREATION HANDLERS ---
    const handleGeneratePost = async (topic: string) => {
        setIsLoading(true);
        setCreateModalOpen(false);
        try {
            const newPost = await generatePost(topic);
            setFeedItems(prev => [newPost, ...prev]);
        } catch(e) {
            console.error(e);
            alert("Failed to generate post. Check the console for details.");
        } finally {
            setIsLoading(false);
        }
    }
    
    const handleGenerateStory = async (topic: string) => {
        setIsLoading(true);
        setCreateModalOpen(false);
        try {
            const { imageUrl, text } = await generateStory(topic);
            const newStory: Story = {
                id: `story-${Date.now()}`,
                author: USER_PROFILE,
                imageUrl,
                text,
                duration: 5000,
            };
            setStories(prev => [newStory, ...prev]);
        } catch (e) {
            console.error(e);
            alert("Failed to generate story. Check the console for details.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleGenerateVideo = async (prompt: string, image?: { data: string; mimeType: string; }) => {
        const keySelected = await window.aistudio.hasSelectedApiKey();
        if (!keySelected) {
            setHasApiKey(false);
            return;
        }
        setHasApiKey(true);
        setIsVideoLoading(true);
        setCreateModalOpen(false);

        const messages = [
            "Contacting the visual cortex...",
            "Reticulating splines...",
            "Warming up the render farm...",
            "Composing the digital symphony...",
            "Polishing the final frames..."
        ];

        let messageIndex = 0;
        setVideoLoadingMessage(messages[messageIndex]);
        const interval = setInterval(() => {
            messageIndex = (messageIndex + 1) % messages.length;
            setVideoLoadingMessage(messages[messageIndex]);
        }, 4000);
        
        try {
            const videoDataUrl = await generateVideo(prompt, image);
            const newVideo: VideoData = {
                id: `video-${Date.now()}`,
                type: 'video',
                author: USER_PROFILE,
                text: prompt,
                videoUrl: videoDataUrl,
                timestamp: Date.now(),
                stats: { likes: 0, comments: 0, shares: 0 },
            };
            setGeneratedVideo(newVideo); // Show the video card
            setFeedItems(prev => [newVideo, ...prev]);
        } catch (e: any) {
            console.error(e);
            alert(e.message || "Failed to generate video. Check the console.");
            if (e.message?.includes("API key not found")) {
                setHasApiKey(false); // Prompt user to re-select key
            }
        } finally {
            clearInterval(interval);
            setIsVideoLoading(false);
            setVideoLoadingMessage('');
        }
    };
    
    const handleCreatePost = async (caption: string, file: File) => {
         setIsLoading(true);
         setCreateModalOpen(false);
         try {
            if (file.type.startsWith('video/')) {
                // Bunny.net upload flow
                const bunnyVideoId = await uploadVideoToBunny(file, (progress) => {
                    // Here you could update a progress bar state
                    console.log(`Upload progress: ${progress}%`);
                });
                const newVideoPost: VideoData = {
                     id: `post-${Date.now()}`,
                     type: 'video',
                     author: USER_PROFILE,
                     text: caption,
                     bunnyVideoId: bunnyVideoId,
                     timestamp: Date.now(),
                     stats: { likes: 0, comments: 0, shares: 0 },
                };
                setFeedItems(prev => [newVideoPost, ...prev]);
            } else {
                // Regular image upload flow
                 const reader = new FileReader();
                 reader.onloadend = () => {
                     const newPost: Post = {
                         id: `post-${Date.now()}`,
                         type: 'post',
                         author: USER_PROFILE,
                         text: caption,
                         imageUrl: reader.result as string,
                         timestamp: Date.now(),
                         source: 'uploaded',
                         stats: { likes: 0, comments: 0, shares: 0 },
                     };
                     setFeedItems(prev => [newPost, ...prev]);
                 };
                 reader.readAsDataURL(file);
            }
         } catch(e) {
             console.error(e);
             alert("Failed to create post. See console for details.");
         } finally {
             setIsLoading(false);
         }
    };
    

    const renderView = () => {
        if (isConversationView && currentConversation) {
             return <ConversationView 
                conversation={currentConversation} 
                onUpdate={handleUpdateConversation}
                onBack={() => setConversationView(false)} 
             />;
        }

        // --- Video Generation Flow ---
        if (isVideoLoading) {
            return <div className="container mx-auto px-4 mt-8"><VideoLoading message={videoLoadingMessage} /></div>;
        }
        if (hasApiKey === false) {
             return <div className="container mx-auto px-4 mt-8"><ApiKeySelector onSelectKey={async () => {
                await window.aistudio.openSelectKey();
                setHasApiKey(true);
             }} /></div>;
        }
        if (generatedVideo) {
            // This is just to show the generated video card immediately
            // It will also be in the feed
            return <div className="container mx-auto px-4 mt-8"><FeedView feedItems={[generatedVideo]} stories={stories} isLoading={false} onAddStoryClick={() => setCreateModalOpen(true)} onStoryClick={setCurrentStory} /></div>
        }
        // --- End Video Flow ---


        switch (view) {
            case 'feed':
                return <FeedView feedItems={feedItems} stories={stories} isLoading={isLoading} onAddStoryClick={() => setCreateModalOpen(true)} onStoryClick={setCurrentStory} />;
            case 'explore':
                return <ExploreView />;
            case 'messages':
                return <MessagesView conversations={conversations} onConversationSelect={handleConversationSelect} onBack={() => setView('feed')} />;
            case 'profile':
                return <ProfileView />;
            default:
                return null;
        }
    };

    return (
        <div className="bg-slate-900 text-slate-100 min-h-screen font-sans">
            {!isConversationView && <Header />}
            <main className={`container mx-auto ${!isConversationView && 'pb-20'}`}>
                {renderView()}
            </main>
            {!isConversationView && (
                <BottomNavBar 
                    activeView={view} 
                    onNavigate={handleNavigate} 
                    onAddClick={() => setCreateModalOpen(true)}
                />
            )}
            {isCreateModalOpen && (
                <CreateModal 
                    onClose={() => setCreateModalOpen(false)}
                    onGeneratePost={handleGeneratePost}
                    onGenerateStory={handleGenerateStory}
                    onGenerateVideo={handleGenerateVideo}
                    onCreatePost={handleCreatePost}
                />
            )}
            {currentStory && <StoryViewer story={currentStory} onClose={() => setCurrentStory(null)} />}
        </div>
    );
};

export default App;
