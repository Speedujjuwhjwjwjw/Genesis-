// This service simulates a backend that securely handles video uploads to Bunny.net.
// In a real application, this logic would live on a server, and the client
// would call your server's API endpoints. The API keys should NEVER be
// exposed on the client.

// IMPORTANT: Add these to a .env.local file for a real project.
// For this environment, you might need to replace them directly, but
// be aware this is not a secure practice for production.
const BUNNY_STREAM_LIBRARY_ID = process.env.BUNNY_STREAM_LIBRARY_ID || 'YOUR_BUNNY_STREAM_LIBRARY_ID';
const BUNNY_API_KEY = process.env.BUNNY_API_KEY || 'YOUR_BUNNY_API_KEY';

interface CreateVideoResponse {
    guid: string;
    // ... other properties returned by Bunny API
}

/**
 * Step 1: Create a video object in Bunny Stream.
 * This is like creating a placeholder for the video.
 * In a real app, this would be a backend endpoint.
 * @param title The title of the video (e.g., the filename)
 * @returns The GUID (unique ID) of the created video object.
 */
async function createVideo(title: string): Promise<string> {
    if (BUNNY_STREAM_LIBRARY_ID === 'YOUR_BUNNY_STREAM_LIBRARY_ID' || BUNNY_API_KEY === 'YOUR_BUNNY_API_KEY') {
        console.warn("Bunny.net credentials are not set. Using mock upload.");
        // Mock response for environments without keys
        return `mock-guid-${Date.now()}`;
    }
    
    const url = `https://video.bunnycdn.com/library/${BUNNY_STREAM_LIBRARY_ID}/videos`;
    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'AccessKey': BUNNY_API_KEY,
        },
        body: JSON.stringify({ title }),
    };

    const response = await fetch(url, options);
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to create Bunny video object: ${errorText}`);
    }

    const data: CreateVideoResponse = await response.json();
    return data.guid;
}

/**
 * Step 2: Upload the actual video file to the created placeholder.
 * In a real app, the backend would create the video object and return the GUID
 * to the frontend. The frontend would then make this upload call directly.
 * @param videoId The GUID of the video object from Step 1.
 * @param file The video file to upload.
 * @param onProgress Callback to report upload progress (0-100).
 */
async function uploadFile(videoId: string, file: File, onProgress: (progress: number) => void): Promise<void> {
    // Mock logic for when credentials are not set
    if (BUNNY_STREAM_LIBRARY_ID === 'YOUR_BUNNY_STREAM_LIBRARY_ID') {
        console.log("Simulating video upload...");
        return new Promise(resolve => {
             let progress = 0;
             const interval = setInterval(() => {
                progress += 20;
                onProgress(progress);
                if (progress >= 100) {
                    clearInterval(interval);
                    console.log("Mock upload complete.");
                    resolve();
                }
             }, 300);
        });
    }

    const url = `https://video.bunnycdn.com/library/${BUNNY_STREAM_LIBRARY_ID}/videos/${videoId}`;
    
    // Using XMLHttpRequest for progress tracking, as it's more straightforward than fetch for this.
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('PUT', url, true);
        xhr.setRequestHeader('AccessKey', BUNNY_API_KEY);
        
        xhr.upload.onprogress = (event) => {
            if (event.lengthComputable) {
                const percentComplete = Math.round((event.loaded / event.total) * 100);
                onProgress(percentComplete);
            }
        };

        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                resolve();
            } else {
                reject(new Error(`Upload failed: ${xhr.statusText}`));
            }
        };

        xhr.onerror = () => reject(new Error('Upload failed due to a network error.'));

        xhr.send(file);
    });
}

/**
 * Main function to orchestrate the two-step upload process.
 * The client would call this single function.
 * @param file The video file from the user's input.
 * @param onProgress Callback to report upload progress.
 * @returns The Bunny Video ID to be stored in your database.
 */
export async function uploadVideo(file: File, onProgress: (progress: number) => void): Promise<string> {
    try {
        onProgress(0);
        // Step 1: Tell Bunny we're about to upload a video
        const videoId = await createVideo(file.name);
        // Step 2: Upload the file to the placeholder we created
        await uploadFile(videoId, file, onProgress);
        onProgress(100);
        return videoId;
    } catch (error) {
        console.error("Bunny.net upload failed:", error);
        throw error;
    }
}
