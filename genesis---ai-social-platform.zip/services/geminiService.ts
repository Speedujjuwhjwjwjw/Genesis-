// FIX: Import Part for multimodal generation.
import { GoogleGenAI, Part } from "@google/genai";
// FIX: Import Author type.
import { Post, Author } from "../types";

// NOTE: This is a placeholder for a real user.
// FIX: MOCK_USER now conforms to the Author type by adding 'id' and 'isUser' properties.
const MOCK_USER: Author = {
    id: 'user-001',
    name: 'You',
    avatarUrl: '/avatars/user.png',
    isUser: true,
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Using a basic text model for text generation
const textModel = "gemini-2.5-flash";
// Using Imagen for high-quality image generation
const imageModel = "imagen-4.0-generate-001";
// Using Veo for video generation
const videoModel = "veo-3.1-fast-generate-preview";


export async function generatePostText(topic: string): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model: textModel,
            contents: `Generate a short, engaging social media post about "${topic}". The post should be 1-2 sentences long. Do not use hashtags.`,
            config: {
                temperature: 0.8,
                maxOutputTokens: 100,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error generating post text:", error);
        throw new Error("Failed to generate post text.");
    }
}

export async function generatePostImage(prompt: string): Promise<string> {
    try {
        const response = await ai.models.generateImages({
            model: imageModel,
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '1:1',
            }
        });
        const base64ImageBytes = response.generatedImages[0].image.imageBytes;
        return base64ImageBytes;
    } catch (error) {
        console.error("Error generating post image:", error);
        throw new Error("Failed to generate image.");
    }
}

// FIX: Implement and export the missing generateCaptionAndHashtags function.
export async function generateCaptionAndHashtags(imagePart: Part): Promise<string> {
    try {
        const textPart = {
            text: "Generate a short, engaging social media caption for this image. Include 2-3 relevant hashtags at the end."
        };
        const response = await ai.models.generateContent({
            model: textModel,
            contents: { parts: [imagePart, textPart] },
            config: {
                temperature: 0.7,
                maxOutputTokens: 150,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error generating caption:", error);
        throw new Error("Failed to generate caption.");
    }
}

export async function generatePost(topic: string): Promise<Post> {
    const postText = await generatePostText(topic);
    // Use a slightly modified prompt for better image results from the post text
    const imagePrompt = `${postText}, photorealistic, high detail, 8k`;
    const imageBase64 = await generatePostImage(imagePrompt);

    return {
        id: `post-${Date.now()}`,
        type: 'post',
        author: MOCK_USER,
        text: postText,
        imageUrl: `data:image/jpeg;base64,${imageBase64}`,
        timestamp: Date.now(),
        // FIX: Add the 'source' property required by the Post type.
        source: 'generated',
        stats: {
            likes: Math.floor(Math.random() * 1000),
            comments: Math.floor(Math.random() * 200),
            shares: Math.floor(Math.random() * 100),
        },
    };
}


export async function generateStory(topic: string): Promise<{imageUrl: string, text: string}> {
    const imagePrompt = `${topic}, vertical shot, cinematic, immersive`;
    const imageBase64 = await generatePostImage(imagePrompt);

    const textResponse = await ai.models.generateContent({
        model: textModel,
        contents: `Generate a very short, one or two-word caption for an image about "${topic}".`,
        config: {
            maxOutputTokens: 10,
        }
    });

    return {
        imageUrl: `data:image/jpeg;base64,${imageBase64}`,
        text: textResponse.text.trim(),
    };
}

export async function generateVideo(prompt: string, image?: { data: string; mimeType: string; }): Promise<string> {
    // FIX: A new AI instance is created here to ensure the latest API key is used,
    // especially after the user selects one via the `openSelectKey` dialog.
    const videoAI = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const requestPayload: any = {
        model: videoModel,
        prompt: prompt,
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '9:16'
        }
    };
    
    if (image) {
        requestPayload.image = {
            imageBytes: image.data,
            mimeType: image.mimeType
        }
    }

    try {
        let operation = await videoAI.models.generateVideos(requestPayload);

        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            operation = await videoAI.operations.getVideosOperation({ operation: operation });
        }

        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (!downloadLink) {
            throw new Error("Video generation completed but no download link was found.");
        }

        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        if (!videoResponse.ok) {
            throw new Error(`Failed to download video: ${videoResponse.statusText}`);
        }
        
        const videoBlob = await videoResponse.blob();
        
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                resolve(reader.result as string);
            };
            reader.onerror = reject;
            reader.readAsDataURL(videoBlob);
        });

    } catch (error) {
        console.error("Error during video generation:", error);
        if (error instanceof Error && error.message.includes("Requested entity was not found.")) {
             throw new Error("API key not found or invalid. Please select a valid API key.");
        }
        throw new Error("Failed to generate video.");
    }
}