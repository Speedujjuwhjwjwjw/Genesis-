import { GoogleGenAI, Chat } from "@google/genai";
import React, { useState, useRef, useEffect } from 'react';
import type { Conversation, Message } from '../types';
import { Icon } from '../components/Icon';

interface ConversationViewProps {
  conversation: Conversation;
  onUpdate: (conversation: Conversation) => void;
  onBack: () => void;
}

export const ConversationView: React.FC<ConversationViewProps> = ({ conversation, onUpdate, onBack }) => {
  const [input, setInput] = useState('');
  const [chat, setChat] = useState<Chat | null>(null);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const newChat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: conversation.persona.systemInstruction,
        },
        // Prime the chat history
        history: conversation.messages.map(msg => ({
            role: msg.sender === 'user' ? 'user' : 'model',
            parts: [{ text: msg.text }]
        }))
    });
    setChat(newChat);
  }, [conversation.persona.id, conversation.persona.systemInstruction, conversation.messages]);
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversation.messages, isAiTyping]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !chat || isAiTyping) return;

    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      text: input,
      sender: 'user',
      timestamp: Date.now(),
    };
    
    let currentMessages = [...conversation.messages, userMessage];
    onUpdate({ ...conversation, messages: currentMessages });
    
    const localInput = input;
    setInput('');
    setIsAiTyping(true);

    try {
        const responseStream = await chat.sendMessageStream({ message: localInput });
        
        let aiResponseText = '';
        const aiMessageId = `msg-${Date.now()}-ai`;

        for await (const chunk of responseStream) {
            aiResponseText += chunk.text;
            const currentAiMessage: Message = {
                id: aiMessageId,
                text: aiResponseText,
                sender: 'ai',
                timestamp: Date.now(),
            };
            
            // Filter out any previous version of the streaming AI message from our local list
            const messagesWithoutStreaming = currentMessages.filter(m => m.id !== aiMessageId);
            
            // Update the local list for the next iteration
            currentMessages = [...messagesWithoutStreaming, currentAiMessage];
            
            // Send the full updated conversation to the parent
            onUpdate({ ...conversation, messages: currentMessages });
        }
    } catch (err) {
        console.error("Error sending message:", err);
        const errorMessage: Message = {
            id: `err-${Date.now()}`,
            text: "Sorry, I encountered an error. Please try again.",
            sender: 'ai',
            timestamp: Date.now(),
        };
        // Add error message to the current message list
        onUpdate({ ...conversation, messages: [...currentMessages, errorMessage] });
    } finally {
        setIsAiTyping(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center p-2 border-b border-slate-700">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-slate-700/50">
          <Icon name="back" />
        </button>
        <img src={conversation.persona.avatarUrl} alt={conversation.persona.name} className="w-10 h-10 rounded-full ml-2" />
        <p className="ml-3 font-bold">{conversation.persona.name}</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {conversation.messages.map((message) => (
          <div key={message.id} className={`flex items-end gap-2 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            {message.sender === 'ai' && <img src={conversation.persona.avatarUrl} className="w-6 h-6 rounded-full self-start" alt="" />}
            <div className={`max-w-xs md:max-w-md px-4 py-2 rounded-2xl ${message.sender === 'user' ? 'bg-purple-600 text-white rounded-br-lg' : 'bg-slate-700 text-slate-200 rounded-bl-lg'}`}>
              <p className="whitespace-pre-wrap">{message.text}</p>
            </div>
          </div>
        ))}
        {isAiTyping && (
             <div className="flex items-end gap-2 justify-start">
                 <img src={conversation.persona.avatarUrl} className="w-6 h-6 rounded-full self-start" alt="" />
                 <div className="px-4 py-3 rounded-2xl bg-slate-700 rounded-bl-lg">
                    <div className="flex items-center gap-1.5">
                        <span className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                        <span className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                        <span className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-pulse"></span>
                    </div>
                 </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-slate-700">
        <form onSubmit={handleSend} className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-slate-800 border border-slate-600 rounded-full px-4 py-2 text-slate-200 placeholder-slate-500 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            disabled={isAiTyping}
          />
          <button type="submit" disabled={!input.trim() || isAiTyping} className="p-2 bg-purple-600 text-white rounded-full disabled:bg-slate-600 disabled:cursor-not-allowed hover:bg-purple-700 transition-colors">
            <Icon name="send" />
          </button>
        </form>
      </div>
    </div>
  );
};
