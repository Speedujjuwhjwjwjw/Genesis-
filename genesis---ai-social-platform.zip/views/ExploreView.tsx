import React, { useState, useEffect } from 'react';
import { generatePostImage } from '../services/geminiService';

const EXPLORE_PROMPTS = [
    "A majestic bioluminescent forest at night, photorealistic",
    "A sleek, futuristic cityscape in the style of Syd Mead",
    "An astronaut discovering an ancient alien artifact on Mars",
    "A cozy, cluttered library in a victorian mansion, warm lighting",
    "Macro shot of a dewdrop on a spiderweb, intricate details",
    "A tranquil Japanese zen garden with a koi pond, cherry blossoms",
    "An epic fantasy battle with dragons and knights",
    "A surreal, floating island with waterfalls cascading into the clouds",
    "A minimalist abstract painting with bold colors and shapes",
    "A hyper-detailed portrait of a wise old cyborg",
    "A bustling medieval marketplace, full of life and character",
    "A serene underwater coral reef teeming with colorful fish"
];

const ExploreImage: React.FC<{prompt: string}> = ({prompt}) => {
    const [imageUrl, setImageUrl] = useState<string | null>(null);

    useEffect(() => {
        const generate = async () => {
            try {
                const base64 = await generatePostImage(prompt);
                setImageUrl(`data:image/jpeg;base64,${base64}`);
            } catch(e) {
                console.error("Failed to generate explore image:", e);
            }
        };
        generate();
    }, [prompt]);

    if (!imageUrl) {
        return <div className="aspect-square bg-slate-800 rounded-lg animate-pulse"></div>;
    }

    return (
        <div className="aspect-square bg-slate-800 rounded-lg overflow-hidden group">
            <img src={imageUrl} alt={prompt} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"/>
        </div>
    )
}

export const ExploreView: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold text-slate-100 mb-4 px-4 sm:px-0">Explore</h1>
      <div className="grid grid-cols-3 gap-1">
        {EXPLORE_PROMPTS.map(prompt => (
            <ExploreImage key={prompt} prompt={prompt} />
        ))}
      </div>
    </div>
  );
};