import React from 'react';
import type { FeedItem, Story } from '../types';
import { StoriesBar } from '../components/StoriesBar';
import { PostCard } from '../components/PostCard';
import { VideoCard } from '../components/VideoCard';
import { LoadingCard } from '../components/LoadingCard';
import { FeedLoadingIndicator } from '../components/FeedLoadingIndicator';

interface FeedViewProps {
  feedItems: FeedItem[];
  stories: Story[];
  isLoading: boolean;
  onAddStoryClick: () => void;
  onStoryClick: (story: Story) => void;
}

export const FeedView: React.FC<FeedViewProps> = ({ feedItems, stories, isLoading, onAddStoryClick, onStoryClick }) => {
  const showLoadingIndicator = isLoading && feedItems.length === 0;

  return (
    <div className="animate-fade-in">
      <StoriesBar stories={stories} onAddStoryClick={onAddStoryClick} onStoryClick={onStoryClick} />
      <div className="space-y-4 py-4 px-4 sm:px-0">
        {showLoadingIndicator && <FeedLoadingIndicator />}
        
        {isLoading && feedItems.length > 0 && <LoadingCard />}

        {!showLoadingIndicator && feedItems.length === 0 && !isLoading && (
           <div className="text-center p-8 mt-8">
                <h2 className="text-xl font-bold text-slate-200">Your Feed is Empty</h2>
                <p className="text-slate-400 mt-2">
                    Click the '+' button to generate your first post or video!
                </p>
            </div>
        )}
        
        {feedItems.map(item =>
          item.type === 'post' ? (
            <PostCard key={item.id} post={item} />
          ) : (
            <VideoCard key={item.id} video={item} />
          )
        )}
      </div>
    </div>
  );
};
