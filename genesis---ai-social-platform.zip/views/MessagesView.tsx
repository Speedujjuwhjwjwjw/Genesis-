import React from 'react';
import type { Conversation, AIPersona } from '../types';
import { AI_PERSONAS } from '../util/data';
import { Icon } from '../components/Icon';

interface MessagesViewProps {
  conversations: Conversation[];
  onConversationSelect: (persona: AIPersona) => void;
  onBack: () => void;
}

export const MessagesView: React.FC<MessagesViewProps> = ({ conversations, onConversationSelect, onBack }) => {
  const getLastMessage = (personaId: string) => {
    const conversation = conversations.find(c => c.persona.id === personaId);
    const personaName = AI_PERSONAS.find(p => p.id === personaId)?.name;

    if (conversation && conversation.messages.length > 1) { // >1 to skip initial message
      const lastMsg = conversation.messages[conversation.messages.length - 1];
      const prefix = lastMsg.sender === 'user' ? 'You: ' : '';
      const text = lastMsg.text.length > 50 ? `${lastMsg.text.substring(0, 50)}...` : lastMsg.text;
      return `${prefix}${text}`;
    }
    return `Start a conversation with ${personaName}`;
  };

  return (
    <div className="h-full flex flex-col animate-fade-in">
      <div className="flex items-center p-2 border-b border-slate-700 sticky top-0 bg-slate-900/80 backdrop-blur-lg z-10">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-slate-700/50">
           <Icon name="back" />
        </button>
        <h1 className="text-xl font-bold ml-4 text-slate-100">Messages</h1>
      </div>
      <div className="flex-1 overflow-y-auto">
        {AI_PERSONAS.map(persona => (
          <div
            key={persona.id}
            className="flex items-center p-4 border-b border-slate-800 cursor-pointer hover:bg-slate-800/50 transition-colors"
            onClick={() => onConversationSelect(persona)}
          >
            <img src={persona.avatarUrl} alt={persona.name} className="w-14 h-14 rounded-full" />
            <div className="ml-4 overflow-hidden">
              <p className="font-bold text-slate-200">{persona.name}</p>
              <p className="text-sm text-slate-400 truncate">{getLastMessage(persona.id)}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
