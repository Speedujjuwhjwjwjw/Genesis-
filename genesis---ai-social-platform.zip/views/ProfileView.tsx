// FIX: Replaced placeholder content with full component implementation.
import React from 'react';

export const ProfileView: React.FC = () => {
  return (
    <div className="animate-fade-in text-center p-8 mt-8">
      <img
        src="/avatars/user.png"
        alt="User Avatar"
        className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-purple-500"
      />
      <h1 className="text-2xl font-bold text-slate-100">User</h1>
      <p className="text-slate-400 mt-2">
        This is a placeholder profile page. More features coming soon!
      </p>
    </div>
  );
};
