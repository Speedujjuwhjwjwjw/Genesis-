export type Author = {
    id: string;
    name: string;
    avatarUrl: string;
    isUser?: boolean;
};

export interface Post {
    id: string;
    type: 'post';
    author: Author;
    text: string;
    imageUrl: string;
    timestamp: number;
    source: 'generated' | 'uploaded';
    stats: {
        likes: number;
        comments: number;
        shares: number;
    };
}

export interface VideoData {
    id: string;
    type: 'video';
    author: Author;
    text: string;
    bunnyVideoId?: string; // For Bunny.net integration
    videoUrl?: string; // For AI-generated videos
    timestamp: number;
    stats: {
        likes: number;
        comments: number;
        shares: number;
    };
}


export type FeedItem = Post | VideoData;

export interface Story {
    id: string;
    author: Author;
    imageUrl: string;
    text: string;
    duration: number; // in milliseconds
}

export interface AIPersona {
    id: string;
    name: string;
    avatarUrl: string;
    systemInstruction: string;
    greeting: string;
}

export interface Message {
    id: string;
    text: string;
    sender: 'user' | 'ai';
    timestamp: number;
}

export interface Conversation {
    persona: AIPersona;
    messages: Message[];
}
